package com.example.weightapp360final;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import android.content.Intent;




import com.example.weightapp360final.DatabaseHelper;



import java.util.ArrayList;
import java.util.List;

public class UserActivity extends AppCompatActivity {
    private EditText weightEditText;
    private EditText dateEditText;
    private Button saveButton;
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private List<String> entries = new ArrayList<>();
    private DatabaseHelper dbHelper;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        weightEditText = findViewById(R.id.weight);
        dateEditText = findViewById(R.id.date);
        saveButton = findViewById(R.id.save_button);
        listView = findViewById(R.id.list_view);

        dbHelper = new DatabaseHelper(this);
        username = getIntent().getStringExtra("username");

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, entries);
        listView.setAdapter(adapter);

        loadEntries();

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveWeightEntry();
            }
        });

        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            String selectedEntry = entries.get(position);
            showEditDeleteDialog(selectedEntry, position);
            return true;
        });

        Button smsButton = findViewById(R.id.sms_button);
        smsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the SmsPermissionActivity when the button is clicked
                Intent intent = new Intent(UserActivity.this, SmsPermissionActivity.class);
                startActivity(intent);
            }
        });
    }

    private void loadEntries() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_WEIGHT_ENTRIES,
                new String[]{DatabaseHelper.COLUMN_DATE, DatabaseHelper.COLUMN_WEIGHT},
                DatabaseHelper.COLUMN_USERNAME + "=?",
                new String[]{username},
                null, null, null);

        entries.clear();
        while (cursor.moveToNext()) {
            String date = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_DATE));
            float weight = cursor.getFloat(cursor.getColumnIndex(DatabaseHelper.COLUMN_WEIGHT));
            entries.add(date + ": " + weight + " lb");
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }

    private void saveWeightEntry() {
        String date = dateEditText.getText().toString();
        String weightString = weightEditText.getText().toString();

        if (date.isEmpty() || weightString.isEmpty()) {
            Toast.makeText(UserActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        float weight = Float.parseFloat(weightString);

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("INSERT INTO " + DatabaseHelper.TABLE_WEIGHT_ENTRIES +
                " (" + DatabaseHelper.COLUMN_DATE + ", " + DatabaseHelper.COLUMN_WEIGHT + ", " + DatabaseHelper.COLUMN_USERNAME + ") " +
                "VALUES (?, ?, ?)", new Object[]{date, weight, username});

        Toast.makeText(UserActivity.this, "Entry saved", Toast.LENGTH_SHORT).show();
        loadEntries();
    }

    private void showEditDeleteDialog(String entry, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit or Delete Entry")
                .setMessage("What would you like to do with this entry?")
                .setPositiveButton("Edit", (dialog, which) -> showEditDialog(entry, position))
                .setNegativeButton("Delete", (dialog, which) -> deleteEntry(entry, position))
                .setNeutralButton("Cancel", null)
                .show();
    }

    private void deleteEntry(String entry, int position) {
        String[] parts = entry.split(": ");
        String date = parts[0];  // Assuming the format is "date: weight"

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("DELETE FROM " + DatabaseHelper.TABLE_WEIGHT_ENTRIES +
                " WHERE " + DatabaseHelper.COLUMN_DATE + "=? AND " + DatabaseHelper.COLUMN_USERNAME + "=?", new String[]{date, username});

        entries.remove(position);
        adapter.notifyDataSetChanged();
        Toast.makeText(UserActivity.this, "Entry deleted", Toast.LENGTH_SHORT).show();
    }

    private void showEditDialog(String entry, int position) {
        String[] parts = entry.split(": ");
        String date = parts[0];
        float currentWeight = Float.parseFloat(parts[1].split(" ")[0]);

        final EditText input = new EditText(this);
        input.setText(String.valueOf(currentWeight));

        new AlertDialog.Builder(this)
                .setTitle("Edit Weight Entry")
                .setMessage("Enter new weight:")
                .setView(input)
                .setPositiveButton("Save", (dialog, which) -> {
                    String newWeightString = input.getText().toString();
                    if (!newWeightString.isEmpty()) {
                        float newWeight = Float.parseFloat(newWeightString);
                        updateEntry(date, newWeight, position);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void updateEntry(String date, float newWeight, int position) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("UPDATE " + DatabaseHelper.TABLE_WEIGHT_ENTRIES +
                        " SET " + DatabaseHelper.COLUMN_WEIGHT + "=? " +
                        "WHERE " + DatabaseHelper.COLUMN_DATE + "=? AND " + DatabaseHelper.COLUMN_USERNAME + "=?",
                new Object[]{newWeight, date, username});

        // Update the list item
        entries.set(position, date + ": " + newWeight + " kg");
        adapter.notifyDataSetChanged();
        Toast.makeText(UserActivity.this, "Entry updated", Toast.LENGTH_SHORT).show();
    }


}
